﻿namespace GSyonetım
{
    partial class Diger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Diger));
            panel1 = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            button3 = new Button();
            dataGridView1 = new DataGridView();
            dataGridView2 = new DataGridView();
            dataGridView3 = new DataGridView();
            label2 = new Label();
            dataGridView4 = new DataGridView();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            textBox4 = new TextBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.FromArgb(192, 0, 0);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(2, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(1188, 93);
            panel1.TabIndex = 13;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 27F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(196, 17);
            label1.Name = "label1";
            label1.Size = new Size(566, 61);
            label1.TabIndex = 2;
            label1.Text = "Galatasaray Takım Yönetimi";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(3, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(124, 93);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // button3
            // 
            button3.Location = new Point(1041, 557);
            button3.Name = "button3";
            button3.Size = new Size(137, 34);
            button3.TabIndex = 16;
            button3.Text = "Geri Dön";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(5, 126);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(941, 78);
            dataGridView1.TabIndex = 17;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(5, 232);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(941, 86);
            dataGridView2.TabIndex = 20;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(5, 347);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.Size = new Size(941, 87);
            dataGridView3.TabIndex = 21;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(5, 97);
            label2.Name = "label2";
            label2.Size = new Size(72, 20);
            label2.TabIndex = 22;
            label2.Text = "Doktorlar";
            label2.Click += label2_Click;
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(5, 460);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.RowHeadersWidth = 51;
            dataGridView4.Size = new Size(941, 87);
            dataGridView4.TabIndex = 23;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(5, 324);
            label3.Name = "label3";
            label3.Size = new Size(84, 20);
            label3.TabIndex = 24;
            label3.Text = "Antrenorler";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(5, 207);
            label4.Name = "label4";
            label4.Size = new Size(29, 20);
            label4.TabIndex = 25;
            label4.Text = "Lig";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(5, 437);
            label5.Name = "label5";
            label5.Size = new Size(64, 20);
            label5.TabIndex = 26;
            label5.Text = "Personel";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(975, 291);
            textBox4.Name = "textBox4";
            textBox4.PlaceholderText = "ID";
            textBox4.Size = new Size(203, 27);
            textBox4.TabIndex = 27;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(975, 126);
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Adi";
            textBox1.Size = new Size(203, 27);
            textBox1.TabIndex = 28;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(975, 177);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "BransID";
            textBox2.Size = new Size(203, 27);
            textBox2.TabIndex = 29;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(975, 232);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "sezon";
            textBox3.Size = new Size(203, 27);
            textBox3.TabIndex = 30;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(975, 347);
            textBox5.Name = "textBox5";
            textBox5.PlaceholderText = "takımID";
            textBox5.Size = new Size(203, 27);
            textBox5.TabIndex = 31;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(975, 407);
            textBox6.Name = "textBox6";
            textBox6.PlaceholderText = "gorev";
            textBox6.Size = new Size(203, 27);
            textBox6.TabIndex = 32;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(975, 460);
            textBox7.Name = "textBox7";
            textBox7.PlaceholderText = "tesisID";
            textBox7.Size = new Size(203, 27);
            textBox7.TabIndex = 33;
            // 
            // button1
            // 
            button1.Location = new Point(133, 557);
            button1.Name = "button1";
            button1.Size = new Size(115, 34);
            button1.TabIndex = 35;
            button1.Text = "doktor kaldir";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(12, 557);
            button2.Name = "button2";
            button2.Size = new Size(115, 34);
            button2.TabIndex = 34;
            button2.Text = "doktor ekle";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button4
            // 
            button4.Location = new Point(352, 557);
            button4.Name = "button4";
            button4.Size = new Size(89, 34);
            button4.TabIndex = 37;
            button4.Text = "lig kaldır";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(254, 557);
            button5.Name = "button5";
            button5.Size = new Size(92, 34);
            button5.TabIndex = 36;
            button5.Text = "lig ekle";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(568, 557);
            button6.Name = "button6";
            button6.Size = new Size(115, 34);
            button6.TabIndex = 39;
            button6.Text = "antrenor kaldır";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(447, 557);
            button7.Name = "button7";
            button7.Size = new Size(115, 34);
            button7.TabIndex = 38;
            button7.Text = "antrenor ekle";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(831, 557);
            button8.Name = "button8";
            button8.Size = new Size(115, 34);
            button8.TabIndex = 41;
            button8.Text = "personel kaldır";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(700, 557);
            button9.Name = "button9";
            button9.Size = new Size(115, 34);
            button9.TabIndex = 40;
            button9.Text = "personel ekle";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // Diger
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1190, 603);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button4);
            Controls.Add(button5);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(textBox4);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(dataGridView4);
            Controls.Add(label2);
            Controls.Add(dataGridView3);
            Controls.Add(dataGridView2);
            Controls.Add(dataGridView1);
            Controls.Add(button3);
            Controls.Add(panel1);
            Name = "Diger";
            Text = "İslemler";
            Load += Diger_Load_1;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox1;
        private Button button3;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private DataGridView dataGridView3;
        private Label label2;
        private DataGridView dataGridView4;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textBox4;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private Button button1;
        private Button button2;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
    }
}